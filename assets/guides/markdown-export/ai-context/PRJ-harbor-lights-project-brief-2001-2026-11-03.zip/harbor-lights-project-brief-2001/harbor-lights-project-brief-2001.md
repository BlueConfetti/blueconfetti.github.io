---
title: "Harbor Lights project brief"
page_id: "2001"
source_url: "https://example.atlassian.net/wiki/spaces/PRJ/pages/2001/Harbor+Lights+project+brief"
space_key: "PRJ"
parent_id: null
breadcrumb: ["Harbor Lights project brief"]
labels: ["project-brief", "harbor-lights"]
author: "Priya Shah"
last_updated_by: "Sam Lee"
created: "2026-09-01T09:00:00.000Z"
updated: "2026-10-08T15:30:00.000Z"
version: 4
exported: "2026-11-03T16:00:00Z"
---

# Harbor Lights project brief

Harbor Lights replaces the paper visitor log at the North Pier office with a tablet check-in. This brief collects the decisions, scope and open questions in one place.

## Summary

| Item | Current answer |
| --- | --- |
| Sponsor | @Jordan Avery |
| Pilot site | North Pier office |
| Pilot window | 2026-12-01 to 2027-01-29 |
| Status | \[PLANNING\] |

Figures in this brief are planning estimates, not approved budget.

Background reading: the [visitor policy](https://example.atlassian.net/wiki/spaces/PRJ/pages/2900/Visitor+policy) and the [Scope and goals](harbor-lights-project-brief-2001/scope-and-goals-2002.md) page.
