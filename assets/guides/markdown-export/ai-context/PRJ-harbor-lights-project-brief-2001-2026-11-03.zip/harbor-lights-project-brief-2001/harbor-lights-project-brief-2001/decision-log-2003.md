---
title: "Decision log"
page_id: "2003"
source_url: "https://example.atlassian.net/wiki/spaces/PRJ/pages/2003/Decision+log"
space_key: "PRJ"
parent_id: "2001"
breadcrumb: ["Harbor Lights project brief", "Decision log"]
labels: ["harbor-lights", "decisions"]
author: "Priya Shah"
last_updated_by: "Sam Lee"
created: "2026-09-01T09:00:00.000Z"
updated: "2026-10-08T15:30:00.000Z"
version: 4
exported: "2026-11-03T16:00:00Z"
---

# Decision log

| Date | Decision | Owner |
| --- | --- | --- |
| 2026-10-14 | Use shared tablets rather than visitor phones. | @Mei Tanaka |
| 2026-10-21 | Keep visitor records for 30 days during the pilot. | @Jordan Avery |
| 2026-10-28 | Front desk staff can correct a mistaken check-in. | @Alex Romero |

- **Decision:** No visitor photos during the pilot.
