---
title: "Scope and goals"
page_id: "2002"
source_url: "https://example.atlassian.net/wiki/spaces/PRJ/pages/2002/Scope+and+goals"
space_key: "PRJ"
parent_id: "2001"
breadcrumb: ["Harbor Lights project brief", "Scope and goals"]
labels: ["harbor-lights"]
author: "Priya Shah"
last_updated_by: "Sam Lee"
created: "2026-09-01T09:00:00.000Z"
updated: "2026-10-08T15:30:00.000Z"
version: 4
exported: "2026-11-03T16:00:00Z"
---

# Scope and goals

## Goals

1. Check in a visitor in under one minute.
2. Remove the paper log at the pilot site.
3. Export a daily visitor list for the front desk.

## Out of scope

- Badge printing
- Contractor timekeeping
- Other offices during the pilot

![Check-in flow](scope-and-goals-2002.assets/check-in-flow.svg)
