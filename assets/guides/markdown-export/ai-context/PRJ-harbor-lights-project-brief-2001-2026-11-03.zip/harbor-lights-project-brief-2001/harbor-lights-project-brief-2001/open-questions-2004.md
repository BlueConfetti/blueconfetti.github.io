---
title: "Open questions"
page_id: "2004"
source_url: "https://example.atlassian.net/wiki/spaces/PRJ/pages/2004/Open+questions"
space_key: "PRJ"
parent_id: "2001"
breadcrumb: ["Harbor Lights project brief", "Open questions"]
labels: ["harbor-lights"]
author: "Priya Shah"
last_updated_by: "Sam Lee"
created: "2026-09-01T09:00:00.000Z"
updated: "2026-10-08T15:30:00.000Z"
version: 4
exported: "2026-11-03T16:00:00Z"
---

# Open questions

- [ ] Confirm Wi-Fi coverage in the lobby with @Alex Romero
- [ ] Decide who receives the daily export
- [x] Choose the pilot site

## Tracked work

Delivery work is tracked in Jira as [HL-12](https://example.atlassian.net/browse/HL-12) and its sub-tasks.

<!-- macro: jira jql="project = HL AND statusCategory != Done" -->
