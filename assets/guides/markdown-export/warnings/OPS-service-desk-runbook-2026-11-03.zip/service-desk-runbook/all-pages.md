<!-- page 4001: service-desk-runbook.md -->

# Service desk runbook

Source: https://example.atlassian.net/wiki/spaces/OPS/pages/4001/Service+desk+runbook · Updated: 2026-10-08

How the service desk triages a new request. Keep this page current; it is exported for the offline runbook binder.

## Queue dashboard

![Queue dashboard](https://example.atlassian.net/wiki/pages/viewpageattachments.action?pageId=4001&preview=queue-dashboard.png)

## Escalation matrix

<table><tr><th><p>Severity</p></th><th><p>First response</p></th><th><p>Escalate to</p></th></tr><tr><td rowspan="2"><p>High</p></td><td><p>15 minutes</p></td><td><p>@Jordan Avery</p></td></tr><tr><td><p>Outside hours: 30 minutes</p></td><td><p>On-call lead</p></td></tr><tr><td><p>Normal</p></td><td><p>4 business hours</p></td><td><p>Queue owner</p></td></tr></table>

## Team status board

<!-- macro: status-board -->

## Open escalations

<!-- macro: jira jql="project = DESK AND priority = High AND resolution = Unresolved" -->

## Wiring diagram

Desk phone wiring
