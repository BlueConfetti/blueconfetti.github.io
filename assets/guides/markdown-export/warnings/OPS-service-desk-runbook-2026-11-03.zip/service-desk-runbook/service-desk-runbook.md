---
title: "Service desk runbook"
page_id: "4001"
source_url: "https://example.atlassian.net/wiki/spaces/OPS/pages/4001/Service+desk+runbook"
space_key: "OPS"
parent_id: null
breadcrumb: ["Service desk runbook"]
labels: ["runbook"]
author: "Priya Shah"
last_updated_by: "Sam Lee"
created: "2026-09-01T09:00:00.000Z"
updated: "2026-10-08T15:30:00.000Z"
version: 4
exported: "2026-11-03T16:00:00Z"
---

# Service desk runbook

How the service desk triages a new request. Keep this page current; it is exported for the offline runbook binder.

## Queue dashboard

![Queue dashboard](https://example.atlassian.net/wiki/pages/viewpageattachments.action?pageId=4001&preview=queue-dashboard.png)

## Escalation matrix

<table><tr><th><p>Severity</p></th><th><p>First response</p></th><th><p>Escalate to</p></th></tr><tr><td rowspan="2"><p>High</p></td><td><p>15 minutes</p></td><td><p>@Jordan Avery</p></td></tr><tr><td><p>Outside hours: 30 minutes</p></td><td><p>On-call lead</p></td></tr><tr><td><p>Normal</p></td><td><p>4 business hours</p></td><td><p>Queue owner</p></td></tr></table>

## Team status board

<!-- macro: status-board -->

## Open escalations

<!-- macro: jira jql="project = DESK AND priority = High AND resolution = Unresolved" -->

## Wiring diagram

Desk phone wiring
