<!-- page 3001: release-handbook.md -->

# Release handbook

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/3001/Release+handbook · Updated: 2026-10-08

Release handbook notes.

<!-- page 3003: release-handbook/planning/release-calendar.md -->

# Release calendar

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/3003/Release+calendar · Updated: 2026-10-08

Release calendar notes.

<!-- page 3006: release-handbook/shipping/release-checklist.md -->

# Release checklist

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/3006/Release+checklist · Updated: 2026-10-08

Release checklist notes.

<!-- page 3007: release-handbook/shipping/release-checklist/rollback-steps.md -->

# Rollback steps

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/3007/Rollback+steps · Updated: 2026-10-08

Rollback steps notes.

<!-- page 3008: release-handbook/shipping/hotfix-releases.md -->

# Hotfix releases

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/3008/Hotfix+releases · Updated: 2026-10-08

Hotfix releases notes.
