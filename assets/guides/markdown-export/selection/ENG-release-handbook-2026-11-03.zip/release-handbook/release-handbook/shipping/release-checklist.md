---
title: "Release checklist"
page_id: "3006"
source_url: "https://example.atlassian.net/wiki/spaces/ENG/pages/3006/Release+checklist"
space_key: "ENG"
parent_id: "3005"
breadcrumb: ["Release handbook", "Shipping", "Release checklist"]
labels: []
author: "Priya Shah"
last_updated_by: "Sam Lee"
created: "2026-09-01T09:00:00.000Z"
updated: "2026-10-08T15:30:00.000Z"
version: 4
exported: "2026-11-03T16:00:00Z"
---

# Release checklist

Release checklist notes.
