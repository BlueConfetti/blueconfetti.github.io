---
title: "Release handbook"
page_id: "3001"
source_url: "https://example.atlassian.net/wiki/spaces/ENG/pages/3001/Release+handbook"
space_key: "ENG"
parent_id: null
breadcrumb: ["Release handbook"]
labels: []
author: "Priya Shah"
last_updated_by: "Sam Lee"
created: "2026-09-01T09:00:00.000Z"
updated: "2026-10-08T15:30:00.000Z"
version: 4
exported: "2026-11-03T16:00:00Z"
---

# Release handbook

Release handbook notes.
