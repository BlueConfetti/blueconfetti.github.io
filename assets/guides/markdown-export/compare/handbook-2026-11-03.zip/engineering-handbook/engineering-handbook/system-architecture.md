---
title: "System architecture"
page_id: "1004"
source_url: "https://example.atlassian.net/wiki/spaces/ENG/pages/1004/System+architecture"
space_key: "ENG"
parent_id: "1001"
breadcrumb: ["Engineering Handbook", "System architecture"]
labels: ["architecture"]
author: "Priya Shah"
last_updated_by: "Priya Shah"
created: "2026-09-01T09:00:00.000Z"
updated: "2026-11-03T10:05:00.000Z"
version: 5
exported: "2026-11-03T16:00:00Z"
---

# System architecture

Three services, one direction of traffic.

![System overview](system-architecture.assets/system-overview.svg)

## Services

<table><tr><th><p>Service</p></th><th><p>Owner</p></th><th><p>Status</p></th></tr><tr><td><p>Web app</p></td><td><p>@Sam Lee</p></td><td><p>[LIVE]</p></td></tr><tr><td><p>API</p></td><td><p>@Priya Shah</p></td><td><p>[MIGRATING]</p></td></tr><tr><td colspan="3"><p>For access, read <a href="onboarding.md#before-day-one">Onboarding</a>. The database is managed by the platform team.</p></td></tr></table>

> [!WARNING]
> Never connect to the production database from a laptop.
