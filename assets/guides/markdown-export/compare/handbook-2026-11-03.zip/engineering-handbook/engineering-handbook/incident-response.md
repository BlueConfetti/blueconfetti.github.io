---
title: "Incident response"
page_id: "1006"
source_url: "https://example.atlassian.net/wiki/spaces/ENG/pages/1006/Incident+response"
space_key: "ENG"
parent_id: "1001"
breadcrumb: ["Engineering Handbook", "Incident response"]
labels: ["process"]
author: "Jordan Avery"
last_updated_by: "Jordan Avery"
created: "2026-11-03T08:40:00.000Z"
updated: "2026-11-03T08:40:00.000Z"
version: 1
exported: "2026-11-03T16:00:00Z"
---

# Incident response

What to do in the first fifteen minutes of an incident.

1. Open an incident channel and name an incident lead.
2. Post the customer impact in one sentence.
3. Check the [Release checklist](https://example.atlassian.net/wiki/spaces/ENG/pages/1005/Release+checklist) for the most recent change.
