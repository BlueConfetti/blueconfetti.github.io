<!-- page 1001: engineering-handbook.md -->

# Engineering Handbook

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1001/Engineering+Handbook · Updated: 2026-10-08

Everything a new engineer needs, in one place. Start with [Onboarding](engineering-handbook/onboarding.md), then read the [System architecture](engineering-handbook/system-architecture.md).

## Owners

Maintained by @Priya Shah and @Sam Lee. Questions go to the `#eng-help` channel.

> [!NOTE]
> This handbook is the source of truth. If something here is wrong, fix it.

<!-- page 1002: engineering-handbook/onboarding.md -->

# Onboarding

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1002/Onboarding · Updated: 2026-10-08

Your first two weeks, step by step. Day-by-day details are in [First week](engineering-handbook/onboarding/first-week.md).

## Before day one

- [x] Laptop ordered
- [x] Accounts requested
- [ ] Buddy assigned: @Sam Lee

## Who to ask

| Topic | Contact |
| --- | --- |
| Access and accounts | @Priya Shah |
| Code review | @Sam Lee |

<!-- page 1003: engineering-handbook/onboarding/first-week.md -->

# First week

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1003/First+week · Updated: 2026-11-03

- Day 1: set up your machine
- Day 2: ship a small fix, tracked in [ENG-42](https://example.atlassian.net/browse/ENG-42)
- Day 3 to 4: pair on the current sprint
- Day 5: demo your first change at the team review

## Set up your machine

```bash
git clone git@example.com:acme/app.git
cd app
npm ci
npm run check
```

**Troubleshooting**

If tests fail on a fresh clone, check your Node version against `.nvmrc`.

<!-- page 1004: engineering-handbook/system-architecture.md -->

# System architecture

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1004/System+architecture · Updated: 2026-11-03

Three services, one direction of traffic.

![System overview](engineering-handbook/system-architecture.assets/system-overview.svg)

## Services

<table><tr><th><p>Service</p></th><th><p>Owner</p></th><th><p>Status</p></th></tr><tr><td><p>Web app</p></td><td><p>@Sam Lee</p></td><td><p>[LIVE]</p></td></tr><tr><td><p>API</p></td><td><p>@Priya Shah</p></td><td><p>[MIGRATING]</p></td></tr><tr><td colspan="3"><p>For access, read <a href="engineering-handbook/onboarding.md#before-day-one">Onboarding</a>. The database is managed by the platform team.</p></td></tr></table>

> [!WARNING]
> Never connect to the production database from a laptop.

<!-- page 1006: engineering-handbook/incident-response.md -->

# Incident response

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1006/Incident+response · Updated: 2026-11-03

What to do in the first fifteen minutes of an incident.

1. Open an incident channel and name an incident lead.
2. Post the customer impact in one sentence.
3. Check the [Release checklist](https://example.atlassian.net/wiki/spaces/ENG/pages/1005/Release+checklist) for the most recent change.
