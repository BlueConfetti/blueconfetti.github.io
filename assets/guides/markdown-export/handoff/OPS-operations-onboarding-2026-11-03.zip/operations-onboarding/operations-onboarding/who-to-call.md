---
title: "Who to call"
page_id: "6004"
source_url: "https://example.atlassian.net/wiki/spaces/OPS/pages/6004/Who+to+call"
space_key: "OPS"
parent_id: "6001"
breadcrumb: ["Operations onboarding", "Who to call"]
labels: ["onboarding"]
author: "Priya Shah"
last_updated_by: "Sam Lee"
created: "2026-09-01T09:00:00.000Z"
updated: "2026-10-08T15:30:00.000Z"
version: 4
exported: "2026-11-03T16:00:00Z"
---

# Who to call

For anything urgent, call the shift lead first.

| Need | Contact |
| --- | --- |
| Shift lead | @Jordan Avery |
| Facilities | @Alex Romero |
