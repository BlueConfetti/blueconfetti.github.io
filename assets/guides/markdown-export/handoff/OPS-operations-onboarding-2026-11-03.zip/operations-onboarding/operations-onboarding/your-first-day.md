---
title: "Your first day"
page_id: "6002"
source_url: "https://example.atlassian.net/wiki/spaces/OPS/pages/6002/Your+first+day"
space_key: "OPS"
parent_id: "6001"
breadcrumb: ["Operations onboarding", "Your first day"]
labels: ["onboarding"]
author: "Priya Shah"
last_updated_by: "Sam Lee"
created: "2026-09-01T09:00:00.000Z"
updated: "2026-10-08T15:30:00.000Z"
version: 4
exported: "2026-11-03T16:00:00Z"
---

# Your first day

- [ ] Collect your badge at the front desk
- [ ] Walk the site with your buddy
- [ ] Read the safety briefing

![Site map](your-first-day.assets/site-map.svg)

The safety briefing is attached:

[safety-briefing.pdf](your-first-day.assets/safety-briefing.pdf)
