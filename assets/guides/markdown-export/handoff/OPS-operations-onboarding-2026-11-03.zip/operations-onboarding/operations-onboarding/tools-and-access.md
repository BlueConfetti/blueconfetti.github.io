---
title: "Tools and access"
page_id: "6003"
source_url: "https://example.atlassian.net/wiki/spaces/OPS/pages/6003/Tools+and+access"
space_key: "OPS"
parent_id: "6001"
breadcrumb: ["Operations onboarding", "Tools and access"]
labels: ["onboarding"]
author: "Priya Shah"
last_updated_by: "Sam Lee"
created: "2026-09-01T09:00:00.000Z"
updated: "2026-10-08T15:30:00.000Z"
version: 4
exported: "2026-11-03T16:00:00Z"
---

# Tools and access

| Tool | Request from | When |
| --- | --- | --- |
| Ticket queue | @Alex Romero | Day one |
| Shift calendar | @Mei Tanaka | Before day one |
| Door access | Front desk | Day one |
