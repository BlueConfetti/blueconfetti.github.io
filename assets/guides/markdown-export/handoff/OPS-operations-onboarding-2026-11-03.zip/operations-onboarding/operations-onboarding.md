---
title: "Operations onboarding"
page_id: "6001"
source_url: "https://example.atlassian.net/wiki/spaces/OPS/pages/6001/Operations+onboarding"
space_key: "OPS"
parent_id: null
breadcrumb: ["Operations onboarding"]
labels: ["onboarding"]
author: "Priya Shah"
last_updated_by: "Sam Lee"
created: "2026-09-01T09:00:00.000Z"
updated: "2026-10-08T15:30:00.000Z"
version: 4
exported: "2026-11-03T16:00:00Z"
---

# Operations onboarding

Start here during your first week on the operations team.

- [Your first day](operations-onboarding/your-first-day.md)
- [Tools and access](operations-onboarding/tools-and-access.md)
- [Who to call](operations-onboarding/who-to-call.md)

> [!NOTE]
> Travel and purchases follow the [expense policy](https://example.atlassian.net/wiki/spaces/OPS/pages/6900/Expense+policy), which stays in Confluence.
