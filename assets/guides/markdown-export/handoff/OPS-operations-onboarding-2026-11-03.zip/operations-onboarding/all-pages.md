<!-- page 6001: operations-onboarding.md -->

# Operations onboarding

Source: https://example.atlassian.net/wiki/spaces/OPS/pages/6001/Operations+onboarding · Updated: 2026-10-08

Start here during your first week on the operations team.

- [Your first day](operations-onboarding/your-first-day.md)
- [Tools and access](operations-onboarding/tools-and-access.md)
- [Who to call](operations-onboarding/who-to-call.md)

> [!NOTE]
> Travel and purchases follow the [expense policy](https://example.atlassian.net/wiki/spaces/OPS/pages/6900/Expense+policy), which stays in Confluence.

<!-- page 6002: operations-onboarding/your-first-day.md -->

# Your first day

Source: https://example.atlassian.net/wiki/spaces/OPS/pages/6002/Your+first+day · Updated: 2026-10-08

- [ ] Collect your badge at the front desk
- [ ] Walk the site with your buddy
- [ ] Read the safety briefing

![Site map](operations-onboarding/your-first-day.assets/site-map.svg)

The safety briefing is attached:

[safety-briefing.pdf](operations-onboarding/your-first-day.assets/safety-briefing.pdf)

<!-- page 6003: operations-onboarding/tools-and-access.md -->

# Tools and access

Source: https://example.atlassian.net/wiki/spaces/OPS/pages/6003/Tools+and+access · Updated: 2026-10-08

| Tool | Request from | When |
| --- | --- | --- |
| Ticket queue | @Alex Romero | Day one |
| Shift calendar | @Mei Tanaka | Before day one |
| Door access | Front desk | Day one |

<!-- page 6004: operations-onboarding/who-to-call.md -->

# Who to call

Source: https://example.atlassian.net/wiki/spaces/OPS/pages/6004/Who+to+call · Updated: 2026-10-08

For anything urgent, call the shift lead first.

| Need | Contact |
| --- | --- |
| Shift lead | @Jordan Avery |
| Facilities | @Alex Romero |
