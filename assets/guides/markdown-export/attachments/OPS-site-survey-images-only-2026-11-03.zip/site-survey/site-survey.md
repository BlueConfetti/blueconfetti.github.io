---
title: "Site survey"
page_id: "5001"
source_url: "https://example.atlassian.net/wiki/spaces/OPS/pages/5001/Site+survey"
space_key: "OPS"
parent_id: null
breadcrumb: ["Site survey"]
labels: ["facilities"]
author: "Priya Shah"
last_updated_by: "Sam Lee"
created: "2026-09-01T09:00:00.000Z"
updated: "2026-10-08T15:30:00.000Z"
version: 4
exported: "2026-11-03T16:00:00Z"
---

# Site survey

Survey notes for the North Pier office move. Floor plan, photo reference and the signed survey are attached to this page.

## Floor plan

![Floor plan](site-survey.assets/floor-plan.svg)

## Entrance photo

![Entrance reference](site-survey.assets/entrance-photo.svg)

## Signed survey

The signed survey is attached as a PDF:

[Signed survey.pdf](https://example.atlassian.net/wiki/pages/viewpageattachments.action?pageId=5001&preview=Signed%20survey.pdf)

A walkthrough recording and the equipment list are also attached to this page.
