<!-- page 5001: site-survey.md -->

# Site survey

Source: https://example.atlassian.net/wiki/spaces/OPS/pages/5001/Site+survey · Updated: 2026-10-08

Survey notes for the North Pier office move. Floor plan, photo reference and the signed survey are attached to this page.

## Floor plan

![Floor plan](site-survey.assets/floor-plan.svg)

## Entrance photo

![Entrance reference](site-survey.assets/entrance-photo.svg)

## Signed survey

The signed survey is attached as a PDF:

[Signed survey.pdf](https://example.atlassian.net/wiki/pages/viewpageattachments.action?pageId=5001&preview=Signed%20survey.pdf)

A walkthrough recording and the equipment list are also attached to this page.
