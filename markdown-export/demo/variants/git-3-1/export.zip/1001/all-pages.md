<!-- page 1001: 1001.md -->

# Engineering Handbook

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1001/Engineering+Handbook · Updated: 2026-10-08

Everything a new engineer needs, in one place. Start with [Onboarding](1001/1002.md), then read the [Architecture overview](https://example.atlassian.net/wiki/spaces/ENG/pages/1004/Architecture+overview).

## Owners

Maintained by @Priya Shah and @Sam Lee. Questions go to the `#eng-help` channel.

> **Info:**
> This handbook is the source of truth. If something here is wrong, fix it.

<!-- page 1002: 1001/1002.md -->

# Onboarding

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1002/Onboarding · Updated: 2026-10-08

Your first two weeks, step by step. Day-by-day details are in <https://example.atlassian.net/wiki/spaces/ENG/pages/1003/First+week>.

## Before day one

- [x] Laptop ordered
- [x] Accounts requested
- [ ] Buddy assigned: @Sam Lee

## Who to ask

| Topic | Contact |
| --- | --- |
| Access and accounts | @Priya Shah |
| Code review | @Sam Lee |
