---
title: "Engineering Handbook"
page_id: "1001"
source_url: "https://example.atlassian.net/wiki/spaces/ENG/pages/1001/Engineering+Handbook"
space_key: "ENG"
parent_id: null
breadcrumb: ["Engineering Handbook"]
labels: ["handbook"]
author: "Priya Shah"
last_updated_by: "Sam Lee"
created: "2026-09-01T09:00:00.000Z"
updated: "2026-10-08T15:30:00.000Z"
version: 4
exported: "2026-10-11T16:00:00Z"
---

# Engineering Handbook

Everything a new engineer needs, in one place. Start with [Onboarding](https://example.atlassian.net/wiki/spaces/ENG/pages/1002/Onboarding), then read the [[engineering-handbook-1001/architecture-overview-1004|Architecture overview]].

## Owners

Maintained by @Priya Shah and @Sam Lee. Questions go to the `#eng-help` channel.

> [!NOTE]
> This handbook is the source of truth. If something here is wrong, fix it.
