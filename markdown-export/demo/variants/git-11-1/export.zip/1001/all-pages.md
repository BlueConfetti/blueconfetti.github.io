<!-- page 1001: 1001.md -->

# Engineering Handbook

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1001/Engineering+Handbook · Updated: 2026-10-08

Everything a new engineer needs, in one place. Start with [Onboarding](1001/1002.md), then read the [Architecture overview](1001/1004.md).

## Owners

Maintained by @Priya Shah and @Sam Lee. Questions go to the `#eng-help` channel.

> **Info:**
> This handbook is the source of truth. If something here is wrong, fix it.

<!-- page 1002: 1001/1002.md -->

# Onboarding

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1002/Onboarding · Updated: 2026-10-08

Your first two weeks, step by step. Day-by-day details are in <https://example.atlassian.net/wiki/spaces/ENG/pages/1003/First+week>.

## Before day one

- [x] Laptop ordered
- [x] Accounts requested
- [ ] Buddy assigned: @Sam Lee

## Who to ask

| Topic | Contact |
| --- | --- |
| Access and accounts | @Priya Shah |
| Code review | @Sam Lee |

<!-- page 1004: 1001/1004.md -->

# Architecture overview

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1004/Architecture+overview · Updated: 2026-10-08

Three services, one direction of traffic.

![System overview](1001/1004.assets/system-overview.svg)

## Services

<table><tr><th><p>Service</p></th><th><p>Owner</p></th><th><p>Status</p></th></tr><tr><td><p>Web app</p></td><td><p>@Sam Lee</p></td><td><p>[LIVE]</p></td></tr><tr><td><p>API</p></td><td><p>@Priya Shah</p></td><td><p>[MIGRATING]</p></td></tr><tr><td colspan="3"><p>For access, read <a href="1001/1002.md#before-day-one">Onboarding</a>. The database is managed by the platform team.</p></td></tr></table>

> **Warning:**
> Never connect to the production database from a laptop.
