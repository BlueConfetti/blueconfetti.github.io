<!-- page 1001: engineering-handbook.md -->

# Engineering Handbook

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1001/Engineering+Handbook · Updated: 2026-10-08

Everything a new engineer needs, in one place. Start with [Onboarding](https://example.atlassian.net/wiki/spaces/ENG/pages/1002/Onboarding), then read the [Architecture overview](engineering-handbook/architecture-overview.md).

## Owners

Maintained by @Priya Shah and @Sam Lee. Questions go to the `#eng-help` channel.

> [!NOTE]
> This handbook is the source of truth. If something here is wrong, fix it.

<!-- page 1003: engineering-handbook/onboarding/first-week.md -->

# First week

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1003/First+week · Updated: 2026-10-08

- Day 1: set up your machine
- Day 2: ship a small fix, tracked in [ENG-42](https://example.atlassian.net/browse/ENG-42)
- Day 3 to 5: pair on the current sprint

## Set up your machine

```bash
git clone git@example.com:acme/app.git
cd app
npm ci
npm test
```

**Troubleshooting**

If tests fail on a fresh clone, check your Node version against `.nvmrc`.

<!-- page 1004: engineering-handbook/architecture-overview.md -->

# Architecture overview

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1004/Architecture+overview · Updated: 2026-10-08

Three services, one direction of traffic.

![System overview](engineering-handbook/architecture-overview.assets/system-overview.svg)

## Services

<table><tr><th><p>Service</p></th><th><p>Owner</p></th><th><p>Status</p></th></tr><tr><td><p>Web app</p></td><td><p>@Sam Lee</p></td><td><p>[LIVE]</p></td></tr><tr><td><p>API</p></td><td><p>@Priya Shah</p></td><td><p>[MIGRATING]</p></td></tr><tr><td colspan="3"><p>For access, read <a href="https://example.atlassian.net/wiki/spaces/ENG/pages/1002/Onboarding#Before-day-one">Onboarding</a>. The database is managed by the platform team.</p></td></tr></table>

> [!WARNING]
> Never connect to the production database from a laptop.
