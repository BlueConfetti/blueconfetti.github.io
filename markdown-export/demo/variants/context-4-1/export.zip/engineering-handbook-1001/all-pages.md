<!-- page 1003: engineering-handbook-1001/onboarding-1002/first-week-1003.md -->

# First week

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1003/First+week · Updated: 2026-10-08

- Day 1: set up your machine
- Day 2: ship a small fix, tracked in [ENG-42](https://example.atlassian.net/browse/ENG-42)
- Day 3 to 5: pair on the current sprint

## Set up your machine

```bash
git clone git@example.com:acme/app.git
cd app
npm ci
npm test
```

**Troubleshooting**

If tests fail on a fresh clone, check your Node version against `.nvmrc`.
