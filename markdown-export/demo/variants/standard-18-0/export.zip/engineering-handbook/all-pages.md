<!-- page 1002: engineering-handbook/onboarding.md -->

# Onboarding

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1002/Onboarding · Updated: 2026-10-08

Your first two weeks, step by step. Day-by-day details are in <https://example.atlassian.net/wiki/spaces/ENG/pages/1003/First+week>.

## Before day one

- [x] Laptop ordered
- [x] Accounts requested
- [ ] Buddy assigned: @Sam Lee

## Who to ask

| Topic | Contact |
| --- | --- |
| Access and accounts | @Priya Shah |
| Code review | @Sam Lee |

<!-- page 1005: engineering-handbook/release-checklist.md -->

# Release checklist

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1005/Release+checklist · Updated: 2026-10-08

Next release: 2026-10-20 \[IN PROGRESS\]

- [x] Changelog written
- [ ] Staging sign-off by @Priya Shah
- [ ] Announce in `#releases`

- **Decision:** Releases ship on Tuesdays, never Fridays.

## Open release issues

The live issue list is a Confluence macro. Its omission is recorded as a warning in the export.

<!-- macro: jira jql="project = ENG AND resolution = Unresolved" -->
