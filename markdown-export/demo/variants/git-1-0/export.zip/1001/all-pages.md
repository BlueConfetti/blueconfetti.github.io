<!-- page 1001: 1001.md -->

# Engineering Handbook

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1001/Engineering+Handbook · Updated: 2026-10-08

Everything a new engineer needs, in one place. Start with [Onboarding](https://example.atlassian.net/wiki/spaces/ENG/pages/1002/Onboarding), then read the [Architecture overview](https://example.atlassian.net/wiki/spaces/ENG/pages/1004/Architecture+overview).

## Owners

Maintained by @Priya Shah and @Sam Lee. Questions go to the `#eng-help` channel.

> **Info:**
> This handbook is the source of truth. If something here is wrong, fix it.
