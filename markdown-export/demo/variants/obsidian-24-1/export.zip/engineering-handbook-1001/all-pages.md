<!-- page 1004: engineering-handbook-1001/architecture-overview-1004.md -->

# Architecture overview

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1004/Architecture+overview · Updated: 2026-10-08

Three services, one direction of traffic.

![System overview](engineering-handbook-1001/architecture-overview-1004.assets/system-overview.svg)

## Services

<table><tr><th><p>Service</p></th><th><p>Owner</p></th><th><p>Status</p></th></tr><tr><td><p>Web app</p></td><td><p>@Sam Lee</p></td><td><p>[LIVE]</p></td></tr><tr><td><p>API</p></td><td><p>@Priya Shah</p></td><td><p>[MIGRATING]</p></td></tr><tr><td colspan="3"><p>For access, read <a href="https://example.atlassian.net/wiki/spaces/ENG/pages/1002/Onboarding#Before-day-one">Onboarding</a>. The database is managed by the platform team.</p></td></tr></table>

> [!WARNING]
> Never connect to the production database from a laptop.

<!-- page 1005: engineering-handbook-1001/release-checklist-1005.md -->

# Release checklist

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1005/Release+checklist · Updated: 2026-10-08

Next release: 2026-10-20 \[IN PROGRESS\]

- [x] Changelog written
- [ ] Staging sign-off by @Priya Shah
- [ ] Announce in `#releases`

- **Decision:** Releases ship on Tuesdays, never Fridays.

## Open release issues

The live issue list is a Confluence macro. Its omission is recorded as a warning in the export.

<!-- macro: jira jql="project = ENG AND resolution = Unresolved" -->
