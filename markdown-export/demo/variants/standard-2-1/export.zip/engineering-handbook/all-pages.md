<!-- page 1002: engineering-handbook/onboarding.md -->

# Onboarding

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1002/Onboarding · Updated: 2026-10-08

Your first two weeks, step by step. Day-by-day details are in <https://example.atlassian.net/wiki/spaces/ENG/pages/1003/First+week>.

## Before day one

- [x] Laptop ordered
- [x] Accounts requested
- [ ] Buddy assigned: @Sam Lee

## Who to ask

| Topic | Contact |
| --- | --- |
| Access and accounts | @Priya Shah |
| Code review | @Sam Lee |
