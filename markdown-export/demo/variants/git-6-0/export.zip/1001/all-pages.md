<!-- page 1002: 1001/1002.md -->

# Onboarding

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1002/Onboarding · Updated: 2026-10-08

Your first two weeks, step by step. Day-by-day details are in [First week](1001/1002/1003.md).

## Before day one

- [x] Laptop ordered
- [x] Accounts requested
- [ ] Buddy assigned: @Sam Lee

## Who to ask

| Topic | Contact |
| --- | --- |
| Access and accounts | @Priya Shah |
| Code review | @Sam Lee |

<!-- page 1003: 1001/1002/1003.md -->

# First week

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1003/First+week · Updated: 2026-10-08

- Day 1: set up your machine
- Day 2: ship a small fix, tracked in [ENG-42](https://example.atlassian.net/browse/ENG-42)
- Day 3 to 5: pair on the current sprint

## Set up your machine

```bash
git clone git@example.com:acme/app.git
cd app
npm ci
npm test
```

**Troubleshooting**

If tests fail on a fresh clone, check your Node version against `.nvmrc`.
