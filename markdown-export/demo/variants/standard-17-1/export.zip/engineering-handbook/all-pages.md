<!-- page 1001: engineering-handbook.md -->

# Engineering Handbook

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1001/Engineering+Handbook · Updated: 2026-10-08

Everything a new engineer needs, in one place. Start with [Onboarding](https://example.atlassian.net/wiki/spaces/ENG/pages/1002/Onboarding), then read the [Architecture overview](https://example.atlassian.net/wiki/spaces/ENG/pages/1004/Architecture+overview).

## Owners

Maintained by @Priya Shah and @Sam Lee. Questions go to the `#eng-help` channel.

> [!NOTE]
> This handbook is the source of truth. If something here is wrong, fix it.

<!-- page 1005: engineering-handbook/release-checklist.md -->

# Release checklist

Source: https://example.atlassian.net/wiki/spaces/ENG/pages/1005/Release+checklist · Updated: 2026-10-08

Next release: 2026-10-20 \[IN PROGRESS\]

- [x] Changelog written
- [ ] Staging sign-off by @Priya Shah
- [ ] Announce in `#releases`

- **Decision:** Releases ship on Tuesdays, never Fridays.

## Open release issues

The live issue list is a Confluence macro. Its omission is recorded as a warning in the export.

<!-- macro: jira jql="project = ENG AND resolution = Unresolved" -->
